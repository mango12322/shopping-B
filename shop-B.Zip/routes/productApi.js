const express = require("express");
const authContorller = require("../controllers/authController");
const productController = require("../controllers/productController");
const router = express.Router();

// 상품 생성
router.post(
  "/",
  authContorller.authenticate,
  authContorller.chekAdminPermission,
  productController.createProduct
);

module.exports = router;
